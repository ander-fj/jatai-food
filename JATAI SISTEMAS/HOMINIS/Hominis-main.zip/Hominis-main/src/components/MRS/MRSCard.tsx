import { ReactNode, useState } from 'react';
import { motion } from 'framer-motion';
import { LucideIcon, ChevronDown, ChevronUp } from 'lucide-react';

interface MRSCardProps {
  title?: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
  action?: ReactNode;
  icon?: LucideIcon;
  collapsible?: boolean;
  defaultOpen?: boolean;
}

export default function MRSCard({
  title,
  subtitle,
  children,
  className = '',
  action,
  icon: Icon,
  collapsible = false,
  defaultOpen = true
}: MRSCardProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white rounded shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow duration-200 ${className}`}
    >
      {(title || action) && (
        <div
          className={`px-2.5 py-2 border-b border-gray-200 flex items-center justify-between ${collapsible ? 'cursor-pointer hover:bg-gray-50' : ''}`}
          onClick={() => collapsible && setIsOpen(!isOpen)}
        >
          <div className="flex items-center gap-1.5">
            {Icon && (
              <div className="w-5 h-5 bg-gradient-to-br from-[#002b55] to-[#003d73] rounded flex items-center justify-center shadow-md">
                <Icon className="w-2.5 h-2.5 text-[#ffcc00]" />
              </div>
            )}
            <div>
              {title && <h3 className="text-sm font-semibold text-[#002b55]">{title}</h3>}
              {subtitle && <p className="text-[10px] text-gray-500 mt-0.5">{subtitle}</p>}
            </div>
          </div>
          <div className="flex items-center gap-1">
            {action}
            {collapsible && (
              <div className="flex items-center gap-1">
                <span className="text-[10px] text-gray-500">
                  {isOpen ? 'Recolher' : 'Expandir'}
                </span>
                {isOpen ? (
                  <ChevronUp className="w-3 h-3 text-gray-400" />
                ) : (
                  <ChevronDown className="w-3 h-3 text-gray-400" />
                )}
              </div>
            )}
          </div>
        </div>
      )}
      {(!collapsible || isOpen) && (
        <div className="p-2.5">
          {children}
        </div>
      )}
    </motion.div>
  );
}
