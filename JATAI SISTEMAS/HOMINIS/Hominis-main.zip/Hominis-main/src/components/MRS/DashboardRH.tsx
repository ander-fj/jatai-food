import { useState, useEffect } from 'react';
import { Users, UserX, Clock, Calendar, Briefcase, TrendingUp, Download, LayoutDashboard, Camera } from 'lucide-react';
import { motion } from 'framer-motion';
import MRSCard from './MRSCard';
import MRSStatCard from './MRSStatCard';
import PeriodFilter from './PeriodFilter';
import { supabase } from '../../lib/supabase';
import { formatNumber, formatPercent } from '../../lib/format';
import { calculateDateRange } from '../../lib/dateUtils';
import { useAutoRecalculate } from '../../lib/useAutoRecalculate';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface DashboardStats {
  totalEmployees: number;
  absences: number;
  delays: number;
  averageHours: number;
  activeEmployees: number;
  departmentCount: number;
  absenteeismRate: number;
}

interface MonthlyData {
  month: string;
  faltas: number;
  atrasos: number;
}

interface DepartmentData {
  department: string;
  count: number;
}

export default function DashboardRH() {
  const [stats, setStats] = useState<DashboardStats>({
    totalEmployees: 0,
    absences: 0,
    delays: 0,
    averageHours: 0,
    activeEmployees: 0,
    departmentCount: 0,
    absenteeismRate: 0,
  });
  const [monthlyData, setMonthlyData] = useState<MonthlyData[]>([]);
  const [departmentData, setDepartmentData] = useState<DepartmentData[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('all');

  useAutoRecalculate(true, 10000);

  useEffect(() => {
    loadDashboardData();
  }, [selectedPeriod]);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      const { data: employees } = await supabase.from('employees').select('*').eq('active', true);

      const dateRange = calculateDateRange(selectedPeriod);

      let scoresQuery = supabase
        .from('employee_scores')
        .select(`
          employee_id,
          raw_value,
          criterion_id,
          period,
          evaluation_criteria (
            name,
            direction
          )
        `);

      if (selectedPeriod !== 'all') {
        scoresQuery = scoresQuery
          .gte('period', dateRange.start)
          .lte('period', dateRange.end);
      }

      const { data: scores } = await scoresQuery;

      const totalEmployees = employees?.length || 0;
      const activeEmployees = totalEmployees;
      const departments = new Set(employees?.map(e => e.department));

      // Calculate department distribution
      const deptCounts = new Map<string, number>();
      employees?.forEach(emp => {
        deptCounts.set(emp.department, (deptCounts.get(emp.department) || 0) + 1);
      });
      const deptData = Array.from(deptCounts.entries())
        .map(([department, count]) => ({ department, count }))
        .sort((a, b) => b.count - a.count);
      setDepartmentData(deptData);

      const assiduityScores = scores?.filter(s => s.evaluation_criteria?.name === 'Assiduidade') || [];
      const avgAssiduity = assiduityScores.length > 0
        ? assiduityScores.reduce((sum, s) => sum + parseFloat(s.raw_value), 0) / assiduityScores.length
        : 0;

      const absences = Math.round((100 - avgAssiduity) * totalEmployees / 100);

      const punctualityScores = scores?.filter(s => s.evaluation_criteria?.name === 'Pontualidade') || [];
      const avgPunctuality = punctualityScores.length > 0
        ? punctualityScores.reduce((sum, s) => sum + parseFloat(s.raw_value), 0) / punctualityScores.length
        : 0;
      const delays = Math.round(avgPunctuality);

      const hoursScores = scores?.filter(s => s.evaluation_criteria?.name === 'Horas Trabalhadas') || [];
      const averageHours = hoursScores.length > 0
        ? hoursScores.reduce((sum, s) => sum + parseFloat(s.raw_value), 0) / hoursScores.length
        : 0;

      const absenteeismRate = 100 - avgAssiduity;

      setStats({
        totalEmployees,
        absences,
        delays,
        averageHours,
        activeEmployees,
        departmentCount: departments.size,
        absenteeismRate,
      });

      // Load chart data: show employees for short periods, months for longer periods
      const monthlyChartData: MonthlyData[] = [];

      const showEmployees = ['7', '30', '90', 'today', 'yesterday', 'this_week', 'last_week', 'this_month', 'last_month', 'all'].includes(selectedPeriod);

      if (showEmployees) {
        // Show individual employees for short periods
        const employeesWithScores = employees || [];

        for (const emp of employeesWithScores) {
          const empScores = scores?.filter(s => s.employee_id === emp.id) || [];

          const faltasScores = empScores.filter(s => s.evaluation_criteria?.name === 'Assiduidade');
          const avgAssiduity = faltasScores.length > 0
            ? faltasScores.reduce((sum, s) => sum + parseFloat(s.raw_value), 0) / faltasScores.length
            : 100;
          const faltas = Math.max(0, Math.round((100 - avgAssiduity) * 30 / 100));

          const atrasosScores = empScores.filter(s => s.evaluation_criteria?.name === 'Pontualidade');
          const atrasos = atrasosScores.length > 0
            ? Math.max(0, Math.round(atrasosScores.reduce((sum, s) => sum + parseFloat(s.raw_value), 0) / atrasosScores.length))
            : 0;

          monthlyChartData.push({
            month: emp.name.split(' ')[0],
            faltas,
            atrasos,
          });
        }
      } else {
        // Show months for longer periods
        const now = new Date();
        let monthsToShow = 6;

        if (selectedPeriod === '180') monthsToShow = 6;
        else if (selectedPeriod === '365') monthsToShow = 12;
        else monthsToShow = 6;

        for (let i = monthsToShow - 1; i >= 0; i--) {
          const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
          const periodStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-01`;
          const monthName = date.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '');

          const { data: periodScores } = await supabase
            .from('employee_scores')
            .select(`
              raw_value,
              evaluation_criteria (name)
            `)
            .eq('period', periodStr);

          const faltasScores = periodScores?.filter(s => s.evaluation_criteria?.name === 'Assiduidade') || [];
          const avgFaltas = faltasScores.length > 0
            ? Math.round((100 - (faltasScores.reduce((sum, s) => sum + parseFloat(s.raw_value), 0) / faltasScores.length)) * (employees?.length || 1) / 100)
            : 0;

          const atrasosScores = periodScores?.filter(s => s.evaluation_criteria?.name === 'Pontualidade') || [];
          const avgAtrasos = atrasosScores.length > 0
            ? Math.round(atrasosScores.reduce((sum, s) => sum + parseFloat(s.raw_value), 0) / atrasosScores.length)
            : 0;

          monthlyChartData.push({
            month: monthName.charAt(0).toUpperCase() + monthName.slice(1),
            faltas: avgFaltas,
            atrasos: avgAtrasos,
          });
        }
      }

      setMonthlyData(monthlyChartData);
    } catch (error) {
      console.error('Erro ao carregar dashboard:', error);
      setMonthlyData([]);
      setDepartmentData([]);
    } finally {
      setLoading(false);
    }
  };

  const handleScreenshot = async () => {
    try {
      const element = document.body;
      const canvas = await html2canvas(element, {
        backgroundColor: '#f9fafb',
        scale: 2,
        logging: false,
        useCORS: true,
      });

      const link = document.createElement('a');
      link.download = `dashboard-rh-${new Date().toISOString().split('T')[0]}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (error) {
      console.error('Erro ao capturar tela:', error);
      alert('Erro ao capturar tela. Tente novamente.');
    }
  };

  const handleExportPDF = async () => {
    try {
      const element = document.body;
      const originalScrollPos = window.scrollY;

      window.scrollTo(0, 0);

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        scrollY: -window.scrollY,
        scrollX: -window.scrollX,
        windowWidth: document.documentElement.scrollWidth,
        windowHeight: document.documentElement.scrollHeight,
        width: document.documentElement.scrollWidth,
        height: document.documentElement.scrollHeight,
      });

      window.scrollTo(0, originalScrollPos);

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('l', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      let heightLeft = pdfHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
      heightLeft -= pdf.internal.pageSize.getHeight();

      while (heightLeft > 0) {
        position = heightLeft - pdfHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
        heightLeft -= pdf.internal.pageSize.getHeight();
      }

      pdf.save('Dashboard-RH.pdf');
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      alert('Erro ao gerar PDF. Tente novamente.');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-[#002b55] mx-auto"></div>
          <p className="text-gray-600 mt-4 font-medium">Carregando dados...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2.5">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-2">
        <div>
          <h1 className="text-base font-bold text-[#002b55] flex items-center gap-1.5">
            <LayoutDashboard className="w-4 h-4 text-[#ffcc00]" />
            Dashboard RH
          </h1>
          <p className="text-gray-600 mt-0.5 text-xs">Indicadores e métricas de gestão de pessoas</p>
        </div>
        <div className="flex flex-col md:flex-row items-start md:items-center gap-1.5">
          <PeriodFilter
            selectedPeriod={selectedPeriod}
            onPeriodChange={setSelectedPeriod}
          />
          <button
            onClick={handleScreenshot}
            className="px-2 py-1 bg-gradient-to-r from-[#ffcc00] to-[#ffd633] text-[#002b55] rounded hover:shadow-lg transition-all flex items-center gap-1 font-semibold text-xs"
          >
            <Camera className="w-3 h-3" />
            Capturar
          </button>
          <button
            onClick={handleExportPDF}
            className="px-2 py-1 bg-gradient-to-r from-[#002b55] to-[#003d73] text-white font-semibold rounded hover:shadow-lg transition-all flex items-center gap-1 text-xs"
          >
            <Download className="w-3 h-3" />
            PDF
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
        <MRSStatCard
          title="Colaboradores Ativos"
          value={stats.activeEmployees}
          icon={<Users className="w-4 h-4" />}
          trend={2.5}
          colorClass="from-[#002b55] to-[#003d73]"
        />
        <MRSStatCard
          title="Faltas (30 dias)"
          value={stats.absences}
          icon={<UserX className="w-4 h-4" />}
          trend={-5.2}
          colorClass="from-red-600 to-red-700"
        />
        <MRSStatCard
          title="Atrasos (30 dias)"
          value={stats.delays}
          icon={<Clock className="w-4 h-4" />}
          trend={-3.1}
          colorClass="from-amber-600 to-amber-700"
        />
        <MRSStatCard
          title="Horas Médias/Dia"
          value={formatNumber(stats.averageHours, 1)}
          icon={<Calendar className="w-4 h-4" />}
          trend={1.2}
          colorClass="from-emerald-600 to-emerald-700"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-2.5">
        <MRSCard title="Distribuição por Departamento" icon={Briefcase}>
          {departmentData.length === 0 ? (
            <div className="h-20 flex items-center justify-center">
              <div className="text-center">
                <Briefcase className="w-6 h-6 text-gray-300 mx-auto mb-1.5" />
                <p className="text-gray-500 font-medium text-xs">Nenhum departamento cadastrado</p>
                <p className="text-[10px] text-gray-400 mt-0.5">Adicione colaboradores primeiro</p>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              {departmentData.map((dept, index) => {
                const colors = ['bg-[#002b55]', 'bg-blue-600', 'bg-[#ffcc00]', 'bg-emerald-600', 'bg-purple-600', 'bg-pink-600'];
                return (
                  <DepartmentBar
                    key={dept.department}
                    department={dept.department}
                    count={dept.count}
                    total={stats.totalEmployees}
                    color={colors[index % colors.length]}
                  />
                );
              })}
            </div>
          )}
        </MRSCard>

        <MRSCard title="Indicadores Consolidados" icon={TrendingUp}>
          <div className="space-y-1.5">
            <IndicatorRow label="Total de Colaboradores" value={stats.totalEmployees.toString()} color="text-[#002b55]" />
            <IndicatorRow label="Departamentos" value={stats.departmentCount.toString()} color="text-blue-600" />
            <IndicatorRow label="Taxa de Absenteísmo" value={formatPercent(stats.absenteeismRate)} color="text-amber-600" />
            <IndicatorRow label="Média de Horas/Dia" value={`${formatNumber(stats.averageHours, 1)}h`} color="text-emerald-600" />
          </div>
        </MRSCard>
      </div>

      <MRSCard title="Evolução Mensal - Faltas e Atrasos" collapsible defaultOpen>
          {monthlyData.length === 0 ? (
          <div className="h-16 flex items-center justify-center">
            <div className="text-center">
              <Calendar className="w-10 h-10 text-gray-300 mx-auto mb-2" />
              <p className="text-gray-500 font-medium text-xs">Nenhum dado histórico disponível</p>
              <p className="text-[10px] text-gray-400 mt-1">Adicione colaboradores e gere dados históricos</p>
            </div>
          </div>
        ) : (
          <>
            <div className="w-full pb-1">
              <div className="h-20 flex items-end justify-between gap-0.5 px-2">
                {monthlyData.map((item, index) => {
                  const maxValue = Math.max(...monthlyData.map(d => Math.max(d.faltas, d.atrasos)), 1);
                  const faltasHeight = maxValue > 0 ? Math.max(5, (item.faltas / maxValue) * 130) : 0;
                  const atrasosHeight = maxValue > 0 ? Math.max(5, (item.atrasos / maxValue) * 130) : 0;

                  return (
                    <div key={index} className="flex flex-col items-center gap-0.5 flex-1 min-w-0">
                      <div className="w-full flex gap-0.5 items-end justify-center" style={{ height: '65px' }}>
                        <motion.div
                          initial={{ height: 0 }}
                          animate={{ height: item.faltas > 0 ? `${faltasHeight}%` : '0%' }}
                          transition={{ delay: index * 0.05, duration: 0.5 }}
                          className="flex-1 max-w-[4px] bg-gradient-to-t from-red-600 to-red-400 rounded-t hover:opacity-80 transition-opacity cursor-pointer relative group"
                          title={`Faltas: ${item.faltas}`}
                        >
                          {item.faltas > 0 && (
                            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-[9px] px-1 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                              {item.faltas}
                            </div>
                          )}
                        </motion.div>
                        <motion.div
                          initial={{ height: 0 }}
                          animate={{ height: item.atrasos > 0 ? `${atrasosHeight}%` : '0%' }}
                          transition={{ delay: index * 0.05 + 0.05, duration: 0.5 }}
                          className="flex-1 max-w-[4px] bg-gradient-to-t from-amber-600 to-amber-400 rounded-t hover:opacity-80 transition-opacity cursor-pointer relative group"
                          title={`Atrasos: ${item.atrasos}`}
                        >
                          {item.atrasos > 0 && (
                            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-[9px] px-1 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                              {item.atrasos}
                            </div>
                          )}
                        </motion.div>
                      </div>
                      <span className="text-[10px] font-medium text-gray-600 truncate w-full text-center">{item.month}</span>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="flex items-center justify-center gap-3 mt-2.5 pt-2 border-t border-gray-200">
              <div className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 bg-gradient-to-r from-red-600 to-red-400 rounded"></div>
                <span className="text-[10px] text-gray-600">Faltas</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 bg-gradient-to-r from-amber-600 to-amber-400 rounded"></div>
                <span className="text-[10px] text-gray-600">Atrasos</span>
              </div>
            </div>
          </>
        )}
      </MRSCard>
    </div>
  );
}

function DepartmentBar({ department, count, total, color }: { department: string; count: number; total: number; color: string }) {
  const percentage = total > 0 ? (count / total) * 100 : 0;

  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-[10px] font-medium text-gray-700">{department}</span>
        <span className="text-[10px] text-gray-600">{count} colab.</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-1.5 overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className={`h-full ${color} rounded-full`}
        />
      </div>
    </div>
  );
}

function IndicatorRow({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="flex items-center justify-between p-1.5 bg-gray-50 rounded hover:bg-gray-100 transition-colors">
      <span className="text-[10px] font-medium text-gray-700">{label}</span>
      <span className={`text-sm font-bold ${color}`}>{value}</span>
    </div>
  );
}
