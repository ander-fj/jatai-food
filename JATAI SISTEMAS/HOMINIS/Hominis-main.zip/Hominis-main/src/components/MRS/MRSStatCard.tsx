import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface MRSStatCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  trend?: number;
  trendLabel?: string;
  colorClass?: string;
}

export default function MRSStatCard({
  title,
  value,
  icon,
  trend,
  trendLabel = 'vs mês anterior',
  colorClass = 'from-[#002b55] to-[#003d73]'
}: MRSStatCardProps) {
  const getTrendIcon = () => {
    if (trend === undefined) return null;
    if (trend > 0) return <TrendingUp className="w-2.5 h-2.5" />;
    if (trend < 0) return <TrendingDown className="w-2.5 h-2.5" />;
    return <Minus className="w-2.5 h-2.5" />;
  };

  const getTrendColor = () => {
    if (trend === undefined) return '';
    if (trend > 0) return 'text-green-600 bg-green-50';
    if (trend < 0) return 'text-red-600 bg-red-50';
    return 'text-gray-600 bg-gray-50';
  };

  return (
    <motion.div
      whileHover={{ y: -2, shadow: '0 6px 15px -3px rgba(0, 0, 0, 0.1)' }}
      className="bg-white rounded shadow-sm border border-gray-200 p-2.5 hover:shadow-lg transition-all duration-300"
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-[10px] font-medium text-gray-600 mb-1">{title}</p>
          <p className="text-lg font-bold text-[#002b55] mb-1.5">{value}</p>
          {trend !== undefined && (
            <div className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full ${getTrendColor()}`}>
              {getTrendIcon()}
              <span className="text-[9px] font-semibold">
                {Math.abs(trend)}%
              </span>
            </div>
          )}
        </div>
        <div className={`w-7 h-7 rounded bg-gradient-to-br ${colorClass} flex items-center justify-center text-white shadow-md`}>
          {icon}
        </div>
      </div>
    </motion.div>
  );
}
